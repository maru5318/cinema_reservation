class Reservationdetail < ApplicationRecord
    belongs_to :reservation
end
