class Ticket < ApplicationRecord
end
