
Admin.create(
    login_id:"0527",
    name:"金子力丸",
    birthday: "2001-05-27",
    tel: "0#{rand(8..9)}0-#{rand(1000..9999)}-#{rand(1000..9999)}",
    email: "riki@example.com",
    password: "seiwa!",
    password_confirmation: "seiwa!"
)